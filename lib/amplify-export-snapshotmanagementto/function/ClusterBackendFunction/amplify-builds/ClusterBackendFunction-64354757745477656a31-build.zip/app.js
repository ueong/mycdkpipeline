/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/


/* Amplify Params - DO NOT EDIT
	AUTH_SNAPSHOTMANAGEMENTTOE7959597_USERPOOLID
	ENV
	REGION
Amplify Params - DO NOT EDIT */

const express = require('express')
const bodyParser = require('body-parser')
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')
const AWS = require('aws-sdk')
AWS.config.update({ region: process.env.REGION})
const dynamodb = new AWS.DynamoDB.DocumentClient();

let tableName = "DBSnapshotManagement";

// declare a new express app
const app = express()
app.use(bodyParser.json())
app.use(awsServerlessExpressMiddleware.eventContext())

// Enable CORS for all methods
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Headers", "*")
  next()
});


/**********************
 * Example get method *
 **********************/

app.get('/clusters', function(req, res) {
  console.log("REGION#" + process.env.REGION)
  let params = {
    TableName: tableName,
    KeyConditionExpression: '#PK = :PK AND begins_with(#SK, :SK)',
    ExpressionAttributeNames: {
      '#PK': 'PK',
      '#SK': 'SK'
    },
    ExpressionAttributeValues: {
      ':PK': "REGION#" + process.env.REGION,
      ':SK': "CLUSTER#"
    },
  };
  dynamodb.query(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message});
    } else {
      console.log("Success", data.Items);
      res.json({ statusCode: 200, url: req.url, body: data.Items})
    }
  });
  // Add your code here
  // res.json({success: 'get call succeed!', url: req.url});
});

app.get('/clusters/:id/description', function(req, res) {
  let params = {
    TableName: tableName,
    KeyConditionExpression: '#PK = :PK AND begins_with(#SK, :SK)',
    ExpressionAttributeNames: {
      '#PK': 'PK',
      '#SK': 'SK'
    },
    ExpressionAttributeValues: {
      ':PK': "REGION#" + process.env.REGION,
      ':SK': "CLUSTER#" + req.body.clusterId
    },
  };
  dynamodb.query(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message});
    } else {
      console.log("Success", data.latestDBInstancesDescription);
      res.json({ statusCode: 200, url: req.url, body: data.latestClusterDescription})
    }
  });
});

app.get('/clusters/:id/instances-description', function(req, res) {
  let params = {
    TableName: tableName,
    KeyConditionExpression: '#PK = :PK AND begins_with(#SK, :SK)',
    ExpressionAttributeNames: {
      '#PK': 'PK',
      '#SK': 'SK'
    },
    ExpressionAttributeValues: {
      ':PK': "REGION#" + process.env.REGION,
      ':SK': "CLUSTER#" + req.body.clusterId
    },
  };
  dynamodb.query(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message});
    } else {
      console.log("Success", data.latestDBInstancesDescription);
      res.json({ statusCode: 200, url: req.url, body: data.latestDBInstancesDescription})
    }
  });
});

/****************************
* Example post method *
****************************/

app.post("/clusters", async function (req, res) {
  let accountId = req.apiGateway.context.invokedFunctionArn.split(':')[4];

// value={"arn:aws:rds:" + region + ":" + accountId + ":cluster:" + clusterName}
  let params = {
    TableName: tableName,
    Item: {
      PK: "REGION#" + process.env.REGION,
      SK: "CLUSTER#" + req.body.clusterId,
      clusterId: req.body.clusterId,
      clusterArn: "arn:aws:rds:" + process.env.REGION + ":" + accountId+ ":cluster:" + req.body.clusterId,
      enabled: req.body.enabled,
      rpo: {
        days: req.body.rpo.days,
        hours: req.body.rpo.hours,
        minutes: req.body.rpo.minutes,
      },
      retention: {
        days: req.body.rpo.days,
        hours: req.body.rpo.hours,
        minutes: req.body.rpo.minutes,
      },
    },
  };
  console.log(params);
  dynamodb.put(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message });
    } else {
      console.log("Success", data);
      res.json({ statusCode: 200, url: req.url, body: data });
    }
  });
});

// app.post('/clusters/*', function(req, res) {
//   // Add your code here
//   res.json({success: 'post call succeed!', url: req.url, body: req.body})
// });

app.post('/clusters/:id/update-rpo', function (req, res) {
  const params = {
    TableName: tableName,
    Key: {
      PK: "REGION#" + process.env.REGION,
      SK: "CLUSTER#" + req.body.clusterId
    },
    UpdateExpression: 'set #rpo.#days = :days, #rpo.#hours = :hours, #rpo.#minutes = :minutes',
    ExpressionAttributeNames: {
      '#rpo': 'rpo',
      '#days': 'days',
      '#hours': 'hours',
      '#minutes': 'minutes'
    },
    ExpressionAttributeValues: {
      ':days': req.body.days,
      ':hours': req.body.hours,
      ':minutes': req.body.minutes
    }
  };

  dynamodb.update(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message });
    } else {
      console.log("Success", data);
      res.json({ statusCode: 200, url: req.url, body: data });
    }
  });    
});

app.post('/clusters/:id/update-retention', function (req, res) {
  const params = {
    TableName: tableName,
    Key: {
      PK: "REGION#" + process.env.REGION,
      SK: "CLUSTER#" + req.body.clusterId
    },
    UpdateExpression: 'set #retention.#days = :days, #retention.#hours = :hours, #retention.#minutes = :minutes',
    ExpressionAttributeNames: {
      '#retention': 'retention',
      '#days': 'days',
      '#hours': 'hours',
      '#minutes': 'minutes'
    },
    ExpressionAttributeValues: {
      ':days': req.body.days,
      ':hours': req.body.hours,
      ':minutes': req.body.minutes
    }
  };

  dynamodb.update(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message });
    } else {
      console.log("Success", data);
      res.json({ statusCode: 200, url: req.url, body: data });
    }
  });    
});

app.post('/clusters/:id/toggle', function (req, res) {
  const params = {
    TableName: tableName,
    Key: {
      PK: "REGION#" + process.env.REGION,
      SK: "CLUSTER#" + req.body.clusterId
    },
    UpdateExpression: 'set #enabled = :enabled',
    ExpressionAttributeNames: {
      '#enabled': 'enabled'
    },
    ExpressionAttributeValues: {
      ':enabled': req.body.enabled
    }
  };
  dynamodb.update(params, function (err, data) {
    if (err) {
      console.log("Error", err);
      res.json({ statusCode: 500, error: err.message });
    } else {
      console.log("Success", data);
      res.json({ statusCode: 200, url: req.url, body: data });
    }
  });    
});

/****************************
* Example put method *
****************************/

app.put('/clusters', function(req, res) {
  // Add your code here
  res.json({success: 'put call succeed!', url: req.url, body: req.body})
});

app.put('/clusters/*', function(req, res) {
  // Add your code here
  res.json({success: 'put call succeed!', url: req.url, body: req.body})
});

/****************************
* Example delete method *
****************************/

app.delete('/clusters', function(req, res) {
  // Add your code here
  res.json({success: 'delete call succeed!', url: req.url});
});

app.delete('/clusters/*', function(req, res) {
  // Add your code here
  res.json({success: 'delete call succeed!', url: req.url});
});

app.listen(3000, function() {
    console.log("App started")
});

// Export the app object. When executing the application local this does nothing. However,
// to port it to AWS Lambda we will create a wrapper around that will load the app from
// this file
module.exports = app
